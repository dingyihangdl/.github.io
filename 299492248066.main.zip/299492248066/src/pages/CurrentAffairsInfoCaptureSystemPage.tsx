import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { 
  FileText, Database, Clock, CheckCircle, AlertCircle, 
  BarChart2, Download, 
  Calendar, Award, MessageCircle, Book, Briefcase, 
  Globe, Zap, Server, Filter, Repeat, Shield, Star,
  FileSpreadsheet, FileText as FilePdfIcon, FileText as FileWordIcon
} from 'lucide-react';

// 模拟数据
const chartData = [
  { name: '领导人', value: 325 },
  { name: '会议政策', value: 567 },
  { name: '经济发展', value: 432 },
  { name: '社会民生', value: 389 },
  { name: '国际形势', value: 276 },
  { name: '科技文化', value: 314 },
];

const infoSources = [
  {
    id: 1,
    name: '人民网',
    icon: 'https://lf-code-agent.coze.cn/obj/x-ai-cn/299492248066/image/region_images/supplies_images/CurrentAffairsInfoCaptureSystemPage/3.jpeg',
    description: '权威发布党和国家重大政策、重要会议等信息',
    status: '已接入'
  },
  {
    id: 2,
    name: '新华网',
    icon: 'https://lf-code-agent.coze.cn/obj/x-ai-cn/299492248066/image/region_images/supplies_images/CurrentAffairsInfoCaptureSystemPage/4.jpeg',
    description: '提供国内外重要新闻、政策解读和专题报道',
    status: '已接入'
  },
  {
    id: 3,
    name: '求是网',
    icon: 'https://lf-code-agent.coze.cn/obj/x-ai-cn/299492248066/image/region_images/supplies_images/CurrentAffairsInfoCaptureSystemPage/5.jpeg',
    description: '发表重要理论文章、政策研究成果和工作部署',
    status: '已接入'
  },
  {
    id: 4,
    name: '学习强国',
    icon: 'https://lf-code-agent.coze.cn/obj/x-ai-cn/299492248066/image/region_images/supplies_images/CurrentAffairsInfoCaptureSystemPage/2.jpeg',
    description: '提供丰富的学习资源、政策解读和重要讲话',
    status: '已接入'
  }
];

const infoCategories = [
  {
    id: 1,
    name: '领导人重要讲话活动',
    icon: '👤',
    color: 'bg-blue-50 text-blue-500',
    description: '收录党和国家领导人重要讲话、考察调研、会见会谈等活动信息',
    count: 325,
    tag: '最新动态'
  },
  {
    id: 2,
    name: '重要会议政策发布',
    icon: '📋',
    color: 'bg-blue-50 text-blue-500',
    description: '汇总中央和地方重要会议精神、政策文件和法规解读',
    count: 567,
    tag: '政策文件'
  },
  {
    id: 3,
    name: '经济发展政策动态',
    icon: '📈',
    color: 'bg-green-50 text-green-500',
    description: '聚焦经济政策、产业发展、财政金融等领域的政策信息',
    count: 432,
    tag: '经济政策'
  },
  {
    id: 4,
    name: '社会民生与法治建设',
    icon: '🏘️',
    color: 'bg-yellow-50 text-yellow-500',
    description: '涵盖教育、医疗、就业、社保、法治等与民生密切相关的政策',
    count: 389,
    tag: '民生保障'
  },
  {
    id: 5,
    name: '国际形势与外交关系',
    icon: '🌍',
    color: 'bg-red-50 text-red-500',
    description: '跟踪国际形势发展、中国外交政策和重要国际合作信息',
    count: 276,
    tag: '外交动态'
  },
  {
    id: 6,
    name: '科技文化生态环境',
    icon: '🔬',
    color: 'bg-purple-50 text-purple-500',
    description: '关注科技创新、文化发展、生态文明建设等领域的政策',
    count: 314,
    tag: '创新驱动'
  }
];

const infoExamples = [
  {
    id: 1,
    type: '领导人重要讲话',
    typeColor: 'bg-blue-50 text-blue-500',
    source: '人民网',
    date: '2024-06-15',
    title: '习近平总书记在全国科技创新大会上发表重要讲话',
    content: '中共中央总书记、国家主席、中央军委主席习近平近日在全国科技创新大会上发表重要讲话，强调要坚持把科技创新摆在国家发展全局的核心位置，深入实施创新驱动发展战略，加快建设创新型国家。',
    importance: 5,
    keywords: ['科技创新', '高质量发展', '国家战略']
  },
  {
    id: 2,
    type: '重要政策文件',
    typeColor: 'bg-green-50 text-green-500',
    source: '国务院',
    date: '2024-06-14',
    title: '国务院发布《关于进一步深化医疗卫生体制改革的意见》',
    content: '国务院近日印发《关于进一步深化医疗卫生体制改革的意见》，提出要坚持以人民健康为中心，深化医疗、医保、医药联动改革，加快推进医疗保障制度建设，完善医疗服务体系，提高医疗服务质量和效率。',
    importance: 5,
    keywords: ['医疗卫生', '体制改革', '医保']
  }
];

const executionRecords = [
  { date: '2024-06-15 08:00', name: '每日信息抓取任务', status: '已完成', result: '成功' },
  { date: '2024-06-14 08:00', name: '每日信息抓取任务', status: '已完成', result: '成功' },
  { date: '2024-06-13 08:00', name: '每日信息抓取任务', status: '已完成', result: '成功' },
  { date: '2024-06-12 08:00', name: '每日信息抓取任务', status: '已完成', result: '成功' }
];

const CurrentAffairsInfoCaptureSystemPage: React.FC = () => {
  // 获取当前日期和时间
  const getCurrentDateTime = () => {
    const now = new Date();
    const date = now.toISOString().split('T')[0];
    const time = now.toTimeString().split(' ')[0].substring(0, 5);
    return { date, time };
  };

  const { date, time } = getCurrentDateTime();

  // 渲染星级评分
  const renderStars = (count: number) => {
    return Array(5).fill(0).map((_, index) => (
      <Star 
        key={index} 
        size={14} 
        fill={index < count ? '#ffd700' : 'none'} 
        color={index < count ? '#ffd700' : '#d9d9d9'} 
        className="inline-block"
      />
    ));
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* 系统标题和头部信息 */}
        <header className="text-center mb-10">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">时政信息抓取处理系统</h1>
          <p className="text-gray-600 mb-6">AI智能助力政务新势，提供精准政策学习资料</p>
          
          {/* 数据统计卡片 */}
          <div className="flex justify-between items-center bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6 max-w-3xl mx-auto">
            <div className="flex space-x-6">
              <span className="text-gray-600 text-sm">{date}</span>
              <span className="text-gray-600 text-sm">{time}</span>
              <span className="text-gray-600 text-sm">4个</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              <span className="text-green-500 text-sm">无异常</span>
            </div>
          </div>
          
          {/* 操作按钮 */}
          <div className="flex justify-center space-x-4">
            <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200">
              立即开始抓取
            </button>
            <button className="border border-blue-500 text-blue-500 hover:bg-blue-50 px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200">
              查看抓取记录
            </button>
          </div>
        </header>

        {/* 系统概览 */}
        <section className="mb-10">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
            <Database className="mr-2 text-blue-500" size={20} />
            系统概览
          </h2>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <p className="text-gray-600 text-sm mb-6">
              时政信息抓取处理系统是一个集数据爬取、分析、处理为一体的综合平台，可实现对人民网、新华网、学习强国等多个权威新闻网站的内容实时抓取、智能分类、精准筛选，为政策学习提供全面、准确、及时的资料支持。
            </p>
            
            <div className="grid grid-cols-3 gap-8 mb-6">
              <div>
                <p className="text-gray-400 text-xs mb-1">数据源中心</p>
                <p className="text-gray-900 font-bold">4个</p>
              </div>
              <div>
                <p className="text-gray-400 text-xs mb-1">信息总量</p>
                <p className="text-gray-900 font-bold">25,678条</p>
              </div>
              <div>
                <p className="text-gray-400 text-xs mb-1">今日新增</p>
                <p className="text-gray-900 font-bold">156条</p>
              </div>
            </div>
            
            {/* 图表 */}
            <div className="h-64 bg-gray-50 rounded-md p-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="value" fill="#1890ff" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>

        {/* 信息来源与范围 */}
        <section className="mb-10">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
            <MessageCircle className="mr-2 text-blue-500" size={20} />
            信息来源与范围
          </h2>
          
          {/* 信息来源 */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {infoSources.map(source => (
              <div key={source.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-5">
                <div className="flex items-center mb-3">
                  <img 
                    src={source.icon} 
                    alt={source.name} 
                    className="w-10 h-10 rounded object-cover mr-3 flex-shrink-0"
                  />
                  <h3 className="font-bold text-gray-900">{source.name}</h3>
                </div>
                <p className="text-gray-600 text-xs mb-3">{source.description}</p>
                <span className="text-blue-500 text-xs bg-blue-50 px-2 py-1 rounded">
                  {source.status}
                </span>
              </div>
            ))}
          </div>
          
          {/* 信息抓取范围 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
            <h3 className="font-bold text-gray-900 mb-4">信息抓取范围</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-blue-50 rounded-md p-4">
                <div className="flex items-center mb-2">
                  <span className="w-4 h-4 bg-blue-500 rounded-full mr-2"></span>
                  <h4 className="font-bold text-gray-900 text-sm">约时报端</h4>
                </div>
                <p className="text-gray-600 text-xs">
                  仅抓取重要政策法规发布、领导讲话、重要会议等内容，确保信息权威性
                </p>
              </div>
              
              <div className="bg-green-50 rounded-md p-4">
                <div className="flex items-center mb-2">
                  <span className="w-4 h-4 bg-green-500 rounded-full mr-2"></span>
                  <h4 className="font-bold text-gray-900 text-sm">内容相关性</h4>
                </div>
                <p className="text-gray-600 text-xs">
                  系统自动识别与政策相关的内容，等一系列与政策相关的内容均会被纳入
                </p>
              </div>
              
              <div className="bg-yellow-50 rounded-md p-4">
                <div className="flex items-center mb-2">
                  <span className="w-4 h-4 bg-yellow-500 rounded-full mr-2"></span>
                  <h4 className="font-bold text-gray-900 text-sm">信息领域</h4>
                </div>
                <p className="text-gray-600 text-xs">
                  涵盖政治、经济、文化、社会、生态文明等多个领域，全方位覆盖政策信息
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* 时政信息分类 */}
        <section className="mb-10">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
            <Filter className="mr-2 text-blue-500" size={20} />
            时政信息分类
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {infoCategories.map(category => (
              <div key={category.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-5">
                <div className="flex items-center mb-3">
                  <div className={`w-8 h-8 rounded-md flex items-center justify-center mr-2 ${category.color.split(' ')[0]}`}>
                    <span className={category.color.split(' ')[1]}>{category.icon}</span>
                  </div>
                  <h3 className="font-bold text-gray-900 text-sm">{category.name}</h3>
                </div>
                <p className="text-gray-600 text-xs mb-3">{category.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-xs">{category.count} 条</span>
                  <span className={`text-xs ${category.color}`}>{category.tag}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 时政信息示例 */}
        <section className="mb-10">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
            <Book className="mr-2 text-blue-500" size={20} />
            时政信息示例
          </h2>
          
          {infoExamples.map(example => (
            <div key={example.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-4">
              <div className="flex flex-wrap items-center justify-between mb-3">
                <div className="flex items-center mb-2 sm:mb-0">
                  <span className={`text-xs ${example.typeColor} px-2 py-1 rounded mr-2`}>
                    {example.type}
                  </span>
                  <span className="text-gray-400 text-xs">来源：{example.source}</span>
                </div>
                <span className="text-gray-400 text-xs">{example.date}</span>
              </div>
              
              <h3 className="font-bold text-gray-900 mb-3">{example.title}</h3>
              
              <p className="text-gray-600 text-sm mb-3">{example.content}</p>
              
              <div className="flex items-center mb-3">
                <span className="text-gray-400 text-xs mr-2">重要程度：</span>
                <div className="flex">
                  {renderStars(example.importance)}
                </div>
              </div>
              
              <div className="mb-3">
                <span className="text-gray-400 text-xs mr-2">关键词：</span>
                {example.keywords.map((keyword, index) => (
                  <span 
                    key={index} 
                    className="text-gray-600 text-xs bg-gray-100 px-2 py-1 rounded mr-2 mb-2 inline-block"
                  >
                    {keyword}
                  </span>
                ))}
              </div>
              
              <button className="text-blue-500 border border-blue-500 text-xs px-3 py-1 rounded hover:bg-blue-50 transition-colors duration-200">
                查看全文链接
              </button>
            </div>
          ))}
        </section>

        {/* 核心功能 */}
        <section className="mb-10">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
            <Zap className="mr-2 text-blue-500" size={20} />
            核心功能
          </h2>
          
          {/* 定时任务执行 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
            <h3 className="font-bold text-gray-900 mb-4 flex items-center">
              <Clock className="mr-2 text-blue-500" size={18} />
              定时任务执行
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-blue-50 rounded-md p-4">
                <h4 className="font-bold text-blue-500 text-sm mb-2">按时执行</h4>
                <p className="text-gray-600 text-xs">
                  每天上午8:00定时执行信息抓取任务，无需人工干预
                </p>
              </div>
              
              <div className="bg-green-50 rounded-md p-4">
                <h4 className="font-bold text-green-500 text-sm mb-2">任务管理</h4>
                <p className="text-gray-600 text-xs">
                  支持手动触发、暂停、恢复抓取任务，灵活控制抓取过程
                </p>
              </div>
              
              <div className="bg-yellow-50 rounded-md p-4">
                <h4 className="font-bold text-yellow-500 text-sm mb-2">预提醒</h4>
                <p className="text-gray-600 text-xs">
                  提前一天提醒管理员，确保系统运行环境正常
                </p>
              </div>
            </div>
            
            <div className="mb-4">
              <h4 className="font-bold text-gray-900 text-sm mb-2">近期执行记录</h4>
              <div className="bg-gray-50 rounded-md p-4 overflow-hidden">
                <div className="space-y-3">
                  {executionRecords.map((record, index) => (
                    <div 
                      key={index} 
                      className="flex justify-between items-center pb-3 border-b border-gray-200 last:border-0 last:pb-0"
                    >
                      <span className="text-gray-600 text-xs">{record.date}</span>
                      <span className="text-gray-600 text-xs">{record.name}</span>
                      <span className="text-green-500 text-xs bg-green-50 px-2 py-1 rounded">
                        {record.status}
                      </span>
                      <span className="text-gray-600 text-xs">{record.result}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          {/* 其他核心功能 */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center">
                <Server className="mr-2 text-blue-500" size={18} />
                网页内容抓取机制
              </h3>
              
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-blue-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">支持多网站并行抓取，提高信息获取效率</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">智能识别网页结构，提取核心内容，去除广告干扰</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">采用分布式抓取策略，规避网站反爬限制</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">自动处理网页编码、图片、视频等多媒体内容</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center">
                <Filter className="mr-2 text-green-500" size={18} />
                智能分类算法
              </h3>
              
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">基于深度学习的文本分类模型，自动归类信息</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">支持自定义分类标签，灵活调整分类体系</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">人工审核与机器学习相结合，不断优化分类精度</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">对敏感信息进行自动识别和标记，提高信息安全</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center">
                <Repeat className="mr-2 text-yellow-500" size={18} />
                信息优化处理
              </h3>
              
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-yellow-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">自动提取文章关键词和摘要，便于快速浏览</span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">智能去重，避免重复信息干扰</span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">建立信息关联网络，发现潜在联系</span>
                </li>
                <li className="flex items-start">
                  <span className="text-yellow-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">支持信息重要性评级，优先展示核心内容</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center">
                <Shield className="mr-2 text-purple-500" size={18} />
                任务执行状态监控
              </h3>
              
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-purple-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">实时监控抓取任务执行状态，及时发现异常</span>
                </li>
                <li className="flex items-start">
                  <span className="text-purple-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">自动记录错误日志，便于问题排查</span>
                </li>
                <li className="flex items-start">
                  <span className="text-purple-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">设置预警机制，重要异常及时通知管理员</span>
                </li>
                <li className="flex items-start">
                  <span className="text-purple-500 mr-2">✓</span>
                  <span className="text-gray-600 text-xs">提供运行状态统计报表，辅助系统优化决策</span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* 数据导出 */}
        <section className="mb-10">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
            <Download className="mr-2 text-blue-500" size={20} />
            数据导出
          </h2>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* 导出格式支持 */}
              <div>
                <h3 className="font-bold text-gray-900 mb-3">导出格式支持</h3>
                <div className="flex flex-wrap gap-3">
                  <div className="flex items-center bg-gray-100 rounded-md px-3 py-2">
                    <FileText size={18} className="text-blue-500 mr-2" />
                    <span className="text-gray-600 text-sm">Excel格式</span>
                  </div>
                   <div className="flex items-center bg-gray-100 rounded-md px-3 py-2">
                    <FileSpreadsheet size={18} className="text-green-500 mr-2" />
                    <span className="text-gray-600 text-sm">CSV格式</span>
                  </div>
                   <div className="flex items-center bg-gray-100 rounded-md px-3 py-2">
                    <FilePdfIcon size={18} className="text-yellow-500 mr-2" />
                    <span className="text-gray-600 text-sm">PDF格式</span>
                  </div>
                   <div className="flex items-center bg-gray-100 rounded-md px-3 py-2">
                    <FileWordIcon size={18} className="text-purple-500 mr-2" />
                    <span className="text-gray-600 text-sm">Word格式</span>
                  </div>
                </div>
              </div>
              
              {/* 导出设置 */}
              <div>
                <h3 className="font-bold text-gray-900 mb-3">导出设置</h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-gray-600 text-sm mb-1">导出时间范围</label>
                    <select className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm">
                      <option>最近一周</option>
                      <option>最近一月</option>
                      <option>最近三月</option>
                      <option>全部时间</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            
            {/* 导出内容 */}
            <div className="mb-6">
              <h3 className="font-bold text-gray-900 mb-3">导出内容</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2">
                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" defaultChecked />
                  <span className="text-gray-600 text-sm">领导人重要讲话活动</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" defaultChecked />
                  <span className="text-gray-600 text-sm">重要会议政策发布</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" defaultChecked />
                  <span className="text-gray-600 text-sm">经济发展政策动态</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" defaultChecked />
                  <span className="text-gray-600 text-sm">社会民生与法治建设</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" defaultChecked />
                  <span className="text-gray-600 text-sm">国际形势与外交关系</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" defaultChecked />
                  <span className="text-gray-600 text-sm">科技文化生态环境</span>
                </label>
              </div>
            </div>
            
            {/* 导出按钮 */}
            <button className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-md text-sm font-medium transition-colors duration-200 flex items-center justify-center">
              <Download size={16} className="mr-2" />
              立即导出
            </button>
          </div>
        </section>
        
        {/* 页脚 */}
        <footer className="bg-gray-900 text-white py-6 rounded-lg">
          <div className="max-w-5xl mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="mb-4 md:mb-0">
                <h3 className="font-bold text-lg">时政信息抓取处理系统</h3>
                <p className="text-gray-400 text-xs">AI智能助力政务新势，提供精准政策学习资料</p>
              </div>
              <div className="text-gray-400 text-xs">
                © 2024 时政信息抓取处理系统 - 版权所有
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default CurrentAffairsInfoCaptureSystemPage;