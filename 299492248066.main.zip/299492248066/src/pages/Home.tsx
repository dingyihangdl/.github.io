import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">欢迎使用项目模板</h1>
        <p className="text-gray-600 mb-8">选择一个功能开始使用</p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link 
            to="/current-affairs" 
            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-md font-medium transition-colors duration-200"
          >
            进入时政信息抓取处理系统
          </Link>
          <Link 
            to="/other" 
            className="border border-gray-300 hover:bg-gray-50 text-gray-700 px-6 py-3 rounded-md font-medium transition-colors duration-200"
          >
            查看其他功能
          </Link>
        </div>
      </div>
    </div>
  );
}